package com.task.controller;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.task.entities.User;
import com.task.service.UserService;



@RestController
public class TestController {
	@Autowired
	private UserService userService;
	
	@GetMapping("/home")
public String api() {
	return "working";
	
}
	//@ApiOperation(value = "Register User")
	@PostMapping("/adduser")
	public Map<Object, Object> Register(@RequestBody User user) {
		return userService.addUser(user);
	}
	//@ApiOperation(value = "Show User")
	@GetMapping("/GetAll")
	public Map<Object, Object> GetAllData() {
		return userService.GetShowData();
	}
	//@ApiOperation(value = "ById User")
	@GetMapping("/GetById/{id}")
	public Map<Object, Object> GetById(@PathVariable("id")int id) {
		return userService.GetById(id);
	}
	//@ApiOperation(value = "Update User")
	@PutMapping("/update/{id}")
	public Map<Object, Object> Update(@RequestBody User user,@PathVariable("id")int id) {
		user.setId(id);
		return userService.UpdateUserData(user, id);
	}
	//@ApiOperation(value = "Delete User")
	@DeleteMapping("/deleteData/{id}")
	public Map<Object, Object> Delete(@PathVariable("id")int id) {
		return userService.DeleteData(id);
	}
	

}
