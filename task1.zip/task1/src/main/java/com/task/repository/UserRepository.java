package com.task.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.task.entities.User;
@Service
public interface UserRepository extends JpaRepository<User, Integer> {

	List<User> findByFirstNameStartingWith(String first_name);




	
}
