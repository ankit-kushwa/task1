package com.task.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.task.entities.User;
@Service
public interface UserService  {

	Map<Object, Object> addUser(User user);

	Map<Object, Object> GetShowData();

	Map<Object, Object> GetById(int id);

	Map<Object, Object> UpdateUserData(User user, int id);

	Map<Object, Object> DeleteData(int id);

	

	//List<User> findByFirstNameStartingWith(String first_name);

	


	

	


}
