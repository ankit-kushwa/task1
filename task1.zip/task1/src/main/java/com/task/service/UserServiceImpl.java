package com.task.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.task.Util.Constant;
import com.task.entities.User;
import com.task.repository.UserRepository;
@Service
public  class UserServiceImpl implements UserService {
@Autowired
UserRepository userRepository;
	@Override
	public Map<Object, Object> addUser(User user) {
		// TODO Auto-generated method stub
		Map<Object, Object> map=new HashMap<Object, Object>();
		try {
			User user1=new User();
			user1.setFirstName(user.getFirstName());
			user1.setLastName(user.getLastName());
			user1.setEmail(user.getEmail());
			user1.setPassword(user.getPassword());
			user1.setMobile(user.getMobile());
			User sv = userRepository.save(user1);
			map.put(Constant.STATUS, Constant.SUCCESS);
			map.put(Constant.MESSAGE, Constant.REGISTER_SUCCESS_MESSAGE);
		}catch(Exception e) {
			e.printStackTrace();
			map.put(Constant.STATUS, Constant.SERVER_ERROR);
		}
		return map;
	}
	@Override
	public Map<Object, Object> GetShowData() {
		// TODO Auto-generated method stub
		Map<Object, Object> map=new HashMap<Object,Object>();
		try {
			List<User> all = userRepository.findAll();
			map.put("List", all);
			map.put(Constant.STATUS, Constant.SUCCESS);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return map;
	}
	@Override
	public Map<Object, Object> GetById(int id) {
		// TODO Auto-generated method stub
		Map<Object, Object> map=new HashMap<Object, Object>();
		try {
			User byId = userRepository.findById(id).get();
			map.put("Data", byId);
			map.put(Constant.STATUS, Constant.SUCCESS);
		}catch(Exception e) {
			e.printStackTrace();
			map.put(Constant.ERROR_MESSAGE, Constant.SERVER_ERROR);
		}
		return map;
	}
	@Override
	public Map<Object, Object> UpdateUserData(User user, int id) {
		// TODO Auto-generated method stub
		Map<Object, Object> map=new HashMap<Object, Object>();
		try {
			if(user != null) {
				User user1=new User();
				user1.setFirstName(user.getFirstName());
				user1.setLastName(user.getLastName());
				user1.setEmail(user.getEmail());
				user1.setMobile(user.getMobile());
				user1.setPassword(user.getPassword());
				user1.setId(user.getId());
				user1.setId(id);
				User sv = userRepository.save(user1);
				map.put(Constant.STATUS, Constant.SUCCESS);
				map.put(Constant.MESSAGE, Constant.SUB_ADMIN_UPDATE_SUCCESS_MESSAGE);
			}
			else {
				map.put(Constant.ERROR_MESSAGE, Constant.ERROR_MESSAGE);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	
		return map;
	}
	@Override
	public Map<Object, Object> DeleteData(int id) {
		// TODO Auto-generated method stub
		Map<Object, Object> map=new HashMap<Object,Object>();
		try {
			userRepository.deleteById(id);
			map.put(Constant.STATUS, Constant.SUCCESS);
			map.put(Constant.MESSAGE, Constant.ADMIN_DELETE_SUCCESS_MESSAGE);
		}catch(Exception e) {
			e.printStackTrace();
			map.put(Constant.SERVER_ERROR, Constant.SERVER_MESSAGE);
		}
		return map;
	}
	//@Override
	//public List<User> findByFirstNameStartingWith(String first_name) {
		// TODO Auto-generated method stub
		//List<User> response =  userRepository.findByFirstNameStartingWith(first_name);
		//return response;
	//}
		
}
