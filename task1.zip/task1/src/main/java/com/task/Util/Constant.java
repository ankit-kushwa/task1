package com.task.Util;

public class Constant {
	
	/* RESPONSE ATTRIBUTE */
//	public static final String BASE_LINK = "http://36.255.3.15:8092/warehouse-api/";
//	public static final String FORGOT_LINK = "http://localhost:8080/warehouse-api/recover/verify?";
	public static final String FORGOT_LINK = "http://36.255.3.15:8092/warehouse-api/recover/verify?";
	public static final String TYPE_VERIFY = "TscjucFm3GPKE9K9G/dfrw==";
	public static final String TYPE_VERIFIED = "nt7QAJvvcFsoYFONe964xw==";
	public static final String EMAIL_TEMPLATE_IMAGE = "http://36.255.3.15:8092/SHIPNET/assets/email-template.png";
	public static final String EMAIL_TEMPLATE_OTP_IMAGE = "http://36.255.3.15:8092/SHIPNET/assets/email-template-otp.png";
	public static final String VALID = "ufjSeCyE8rx4b7Adecswqg==";
	public static final String INVALID = "A91gv+t+QABPnMhuOli2xQ==";
	public static final String RESPONSE = "response";
	public static final String COUNT = "count";
	public static final String VERIFFY = "verify";
	public static final String RESET = "reset";
	public static final String STATUS = "status";
	public static final String SUCCESS = "200";
	public static final String NOT_AUTHORIZED = "401";
	public static final String SERVER_ERROR = "500";
	public static final String MESSAGE = "message";
	public static final String URL = "url";
	public static final String OTP = "otp";
	public static final String STATE = "states";
	public static final String CITY = "cities";
	public static final String ERROR_MESSAGE = "Please try again";
	public static final String SERVER_MESSAGE = "Internal server error,Try again later!";
	public static final String LIST = "list";
	public static final String DATA = "data";
	public static final String DATA_NOT_FOUND = "No record found!";
	public static final int ZERO = 0;
	public static final int ONE = 1;
	public static final int TWO = 2;
	public static final int THREE = 3;
	public static final String OTP_VERIFICATION = "OTP Verification";
	public static final String RESET_PASSWORD = "Reset Password";
	public static final String USER_LIST = "User list.";
	public static final String COMPANY_LIST = "Company list.";
	public static final String TOTAL_COMPANY = "company_count";
	public static final String TOTAL_USER = "user_count";
	public static final String LOGIN_TYPE = "login_type";
	public static final String COMPANY = "company";
	public static final String USER = "user";
	public static final String LINK_EXPIRE = "Link expire,Please try again!";
	public static final String LOGOUT_SUCCESS_MESSAGE = "Loggedout successfully!";
	public static final String COUNTRIES_LIST = "Countries list!";
	public static final String STATES_LIST = "States list!";
	public static final String CITIES_LIST = "Cities list!";
	
	
	
	/* APP REGISTER MESSAGES */
	public static final String MOBILE_NUMBER_VALIDATE_MESSAGE = "Please enter valid mobile number and.Try again !";
	public static final String MOBILE_NUMBER_ALREADY_REGISTER_MESSAGE = "Please provide another mobile Number,as this number already exist!";
	public static final String EMAIL_EXISTS_MESSAGE = "Please provide another Email, as this Email already exist!";
	public static final String USERNAME_EXISTS_MESSAGE = "Username already exist!";
	public static final String MOBILE_NO_CHANGE_SUCCESS_MESSAGE = "Mobile number successfully changed!";
	public static final String FORGOT_PASSWORD_FAILD_MESSAGE = "We could not verify given email,Please check email and try again!";
	public static final String VERIFY_MOBILE_OR_EMAIL = "we have sent OTP on your registered email and mobile,Please verify your email and mobile number!";
	
	public static final String REGISTER_SUCCESS_MESSAGE = "Registered successfully!";
	public static final String UPDATE_SUCCESS_MESSAGE = "Updated successfully!";
	public static final String LOGIN_SUCCESS_MESSAGE = "Logged in successfully!";
	public static final String LOGIN_FAILD_MESSAGE = "Sorry! Incorrect Email or Password.Please try again.";

	public static final String OTP_SENT_SUCCESS_MESSAGE = "We have sent OTP on your registered email.OTP will be expire in 5 minutes";
	public static final String FORGOT_LINK_SENT_SUCCESS_MESSAGE = "We have sent reset password link on your registered email,Link will be expire in 24 hours";
	public static final String OTP_SENT_FAILD_MESSAGE = "Please check your mobile email and. Try again.";
	public static final String OTP_VERIFY_FAILD_MESSAGE = "Invalid otp,please enter valid OTP!";
	public static final String OTP_EXPIRE_MESSAGE = "OTP expire!,Resend OTP and Try again.";
	public static final String VERIFY_SUCCESS_MESSAGE = "Email Seccessfully verified.";
	
	/* ADMIN MESSAGES */
	public static final String ADMIN_LOGIN_SUCCESS_MESSAGE = "Welcome admin.";
	public static final String ADMIN_DELETE_SUCCESS_MESSAGE = "Sub admin permanent deleted successfully.";
	public static final String ADMIN_INACTIVE_SUCCESS_MESSAGE = "Sub admin delete successfully.";
	public static final String ADMIN_ACTIVE_SUCCESS_MESSAGE = "Sub admin retrived successfully.";
	public static final String SUB_ADMIN_SUCCESS_MESSAGE = "Sub admin added successfully.";
	public static final String SUB_ADMIN_UPDATE_SUCCESS_MESSAGE = "Sub admin updated successfully.";
	public static final String ADMIN_CAN_NOT_DELETE_MESSAGE = "Administrator can not be delete!";
	public static final String ADMIN_CAN_NOT_UPDATE_MESSAGE = "Administrator can not be update!";
	public static final String ADMIN_CAN_NOT_PERFORM_MESSAGE = "You can not perform any action on Administrator!";
	public static final String PASSWORD_CHANGE_SUCCESS_MESSAGE = "Password changed successfully";
	public static final String ADMIN_OLDPASSWORD_ERROR_MESSAGE = "Invalid oldpassword,Please try again!";
	public static final String ACCOUNT_DISABLE_MESSAGE = "Account is temporary disabled.!";
	public static final Object MY_ADDRESS_BOOK = "User address saved successfully";
	public static final Object RECEIVER_ADDRESS_BOOK = "Receiver address saved successfully";
	
	public static final String CONDITION_MESSAGE = "In these Website Standard Terms and Conditions, “Your Content” shall mean any audio, video text, images or other material you choose to display on this Website. By displaying Your Content, you grant Company Name a non-exclusive, worldwide irrevocable, sub licensable license to use, reproduce, adapt, publish, translate and distribute it in any and all media.\r\n" + 
			"\r\n" + 
			"Your Content must be your own and must not be invading any third-party's rights. Company Name reserves the right to remove any of Your Content from this Website at any time without notice";
	public static final Object TERM_CONDITION_SUCESS = "Terms and condition sucessfully saved";
	public static final Object SHIP_OPTION_SUCESS = "Ship option saved successfully";
	public static final Object GOODS_SAVED_SUCESS = "Goods addes successfully";
	public static final Object SHIP_OPTION_LIST = "Ship options list";
	public static final Object GOODS_LIST = "Goods types list";
	public static final Object FORGOT_PASSWORD_SUCCESSFULLY = "Forgot Password successfully";
	public static final Object PLEASE_ENTER_VALID_OTP = "Please Enter Valid Otp";
	public static final Object VARIFY_OTP_SUCCESSFULLY = "Varify Otp Successfully";
	public static final Object USER_NOT_EXIST = "User Not Exit";

}
